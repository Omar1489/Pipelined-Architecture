
public class DataMem {
	public static String[] dataMem = new String[1024];
	
	
}
