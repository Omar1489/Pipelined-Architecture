
public class InstMem {
	public static String[] instMemory = new String[1024];
	
	
	
	
}
